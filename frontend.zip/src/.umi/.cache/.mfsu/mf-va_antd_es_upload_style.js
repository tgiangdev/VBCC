import 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/upload/style';
