(self["webpackChunkqlvb_frontend"] = self["webpackChunkqlvb_frontend"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_antd_es_popconfirm_js"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_antd_es_popconfirm.js":
/*!***********************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_antd_es_popconfirm.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var I_Projects_qlvb_qlvb_frontend_node_modules_antd_es_popconfirm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/antd/es/popconfirm */ "./node_modules/antd/es/popconfirm/index.js");

/* harmony default export */ __webpack_exports__["default"] = (I_Projects_qlvb_qlvb_frontend_node_modules_antd_es_popconfirm__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ })

}]);