import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/result';
export default _;
export * from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/result';
