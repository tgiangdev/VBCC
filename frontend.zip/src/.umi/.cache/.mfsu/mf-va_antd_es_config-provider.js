import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/config-provider';
export default _;
export * from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/config-provider';
