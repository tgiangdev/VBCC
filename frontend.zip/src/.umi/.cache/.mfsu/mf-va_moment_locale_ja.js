import _ from 'moment/locale/ja';
export default _;
export * from 'moment/locale/ja';
