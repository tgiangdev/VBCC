import _ from 'moment/locale/vi';
export default _;
export * from 'moment/locale/vi';
