import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/locale/zh_CN';
export default _;
