(self["webpackChunkqlvb_frontend"] = self["webpackChunkqlvb_frontend"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_antd_es_space_js"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_antd_es_space.js":
/*!******************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_antd_es_space.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SpaceContext": function() { return /* reexport safe */ I_Projects_qlvb_qlvb_frontend_node_modules_antd_es_space__WEBPACK_IMPORTED_MODULE_0__.SpaceContext; }
/* harmony export */ });
/* harmony import */ var I_Projects_qlvb_qlvb_frontend_node_modules_antd_es_space__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/antd/es/space */ "./node_modules/antd/es/space/index.js");

/* harmony default export */ __webpack_exports__["default"] = (I_Projects_qlvb_qlvb_frontend_node_modules_antd_es_space__WEBPACK_IMPORTED_MODULE_0__.default);



/***/ })

}]);