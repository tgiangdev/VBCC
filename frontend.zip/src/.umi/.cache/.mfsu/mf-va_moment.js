import _ from 'moment';
export default _;
export * from 'moment';
