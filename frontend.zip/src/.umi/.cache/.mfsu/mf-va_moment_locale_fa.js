import _ from 'moment/locale/fa';
export default _;
export * from 'moment/locale/fa';
