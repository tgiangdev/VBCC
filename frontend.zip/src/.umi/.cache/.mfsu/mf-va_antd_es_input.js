import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/input';
export default _;
