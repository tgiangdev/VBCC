
# Rating

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rating** | **Integer** | Rating value for a book from one star (bad) to five stars (great) | 



