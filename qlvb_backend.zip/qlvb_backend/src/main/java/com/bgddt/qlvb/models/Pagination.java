package com.bgddt.qlvb.models;

import org.springframework.data.domain.Pageable;

public interface Pagination extends Pageable {
}
