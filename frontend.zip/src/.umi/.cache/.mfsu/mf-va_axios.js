import _ from 'axios';
export default _;
export * from 'axios';
