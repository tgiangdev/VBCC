import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/menu';
export default _;
