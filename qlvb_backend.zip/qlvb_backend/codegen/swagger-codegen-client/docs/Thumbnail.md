
# Thumbnail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Image to display | 
**title** | **String** | Caption of the image | 



