package com.bgddt.qlvb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QlvbApplication {

	public static void main(String[] args) {
		SpringApplication.run(QlvbApplication.class, args);
	}

}
