import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/auto-complete';
export default _;
