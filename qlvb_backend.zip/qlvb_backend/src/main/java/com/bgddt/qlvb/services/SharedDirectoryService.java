package com.bgddt.qlvb.services;

public interface SharedDirectoryService<O, T> extends BaseService<O, T>{
}
