import _ from 'jwt-decode';
export default _;
export * from 'jwt-decode';
