import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/antd/es/typography';
export default _;
