package com.bgddt.qlvb.common.enums;

public enum Role {
    USER,
    ADMIN,
    SYSTEM
}
