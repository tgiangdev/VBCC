import _ from 'moment/locale/bn-bd';
export default _;
export * from 'moment/locale/bn-bd';
