import _ from 'rc-util/es/hooks/useMergedState';
export default _;
