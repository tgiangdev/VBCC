// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from 'I:/Projects/qlvb/qlvb_frontend/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@ant-design/pro-layout/es/PageLoading';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-layout__Layout' */'I:/Projects/qlvb/qlvb_frontend/src/.umi/plugin-layout/Layout.tsx'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/~demos/:uuid",
        "layout": false,
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'I:/Projects/qlvb/qlvb_frontend/node_modules/@umijs/preset-dumi/lib/theme/layout'), loading: LoadingComponent})],
        "component": (props) => React.createElement(
        dynamic({
          loader: async () => {
            const { default: getDemoRenderArgs } = await import(/* webpackChunkName: 'dumi_demos' */ 'I:/Projects/qlvb/qlvb_frontend/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
            const { default: Previewer } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi-theme-default/es/builtins/Previewer.js');
            const { default: demos } = await import(/* webpackChunkName: 'dumi_demos' */ '@@/dumi/demos');
            const { usePrefersColor } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi/theme');

            return props => {
              
      const renderArgs = getDemoRenderArgs(props, demos);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
            }
          }
        }), props)
      },
      {
        "path": "/_demos/:uuid",
        "redirect": "/~demos/:uuid"
      },
      {
        "__dumiRoot": true,
        "layout": false,
        "path": "/~docs",
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'I:/Projects/qlvb/qlvb_frontend/node_modules/@umijs/preset-dumi/lib/theme/layout'), loading: LoadingComponent}), dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'I:/Projects/qlvb/qlvb_frontend/node_modules/dumi-theme-default/es/layout.js'), loading: LoadingComponent})],
        "routes": [
          {
            "path": "/~docs",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'README.md' */'I:/Projects/qlvb/qlvb_frontend/README.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "locale": "en-US",
              "order": null,
              "filePath": "README.md",
              "updatedTime": 1636041306000,
              "slugs": [
                {
                  "depth": 1,
                  "value": "Ant Design Pro",
                  "heading": "ant-design-pro"
                },
                {
                  "depth": 2,
                  "value": "Environment Prepare",
                  "heading": "environment-prepare"
                },
                {
                  "depth": 2,
                  "value": "Provided Scripts",
                  "heading": "provided-scripts"
                },
                {
                  "depth": 3,
                  "value": "Start project",
                  "heading": "start-project"
                },
                {
                  "depth": 3,
                  "value": "Build project",
                  "heading": "build-project"
                },
                {
                  "depth": 3,
                  "value": "Check code style",
                  "heading": "check-code-style"
                },
                {
                  "depth": 3,
                  "value": "Test code",
                  "heading": "test-code"
                },
                {
                  "depth": 2,
                  "value": "More",
                  "heading": "more"
                }
              ],
              "title": "Ant Design Pro"
            },
            "title": "Ant Design Pro"
          },
          {
            "path": "/~docs/components",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'components__index.md' */'I:/Projects/qlvb/qlvb_frontend/src/components/index.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "filePath": "src/components/index.md",
              "updatedTime": 1636041306000,
              "title": "业务组件",
              "sidemenu": false,
              "slugs": [
                {
                  "depth": 1,
                  "value": "业务组件",
                  "heading": "业务组件"
                },
                {
                  "depth": 2,
                  "value": "Footer 页脚组件",
                  "heading": "footer-页脚组件"
                },
                {
                  "depth": 2,
                  "value": "HeaderDropdown 头部下拉列表",
                  "heading": "headerdropdown-头部下拉列表"
                },
                {
                  "depth": 2,
                  "value": "HeaderSearch 头部搜索框",
                  "heading": "headersearch-头部搜索框"
                },
                {
                  "depth": 3,
                  "value": "API",
                  "heading": "api"
                },
                {
                  "depth": 2,
                  "value": "NoticeIcon 通知工具",
                  "heading": "noticeicon-通知工具"
                },
                {
                  "depth": 3,
                  "value": "NoticeIcon API",
                  "heading": "noticeicon-api"
                },
                {
                  "depth": 3,
                  "value": "NoticeIcon.Tab API",
                  "heading": "noticeicontab-api"
                },
                {
                  "depth": 3,
                  "value": "NoticeIconData",
                  "heading": "noticeicondata"
                },
                {
                  "depth": 2,
                  "value": "RightContent",
                  "heading": "rightcontent"
                }
              ],
              "group": {
                "path": "/~docs/components",
                "title": "Components"
              }
            },
            "title": "业务组件 - qlvb_frontend"
          }
        ],
        "title": "qlvb_frontend",
        "component": (props) => props.children
      },
      {
        "path": "/user",
        "layout": false,
        "routes": [
          {
            "path": "/user",
            "routes": [
              {
                "name": "login",
                "path": "/user/login",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__Login' */'I:/Projects/qlvb/qlvb_frontend/src/pages/user/Login'), loading: LoadingComponent}),
                "exact": true
              }
            ]
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/index.html",
        "name": "welcome",
        "icon": "smile",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
        "hideInMenu": true,
        "exact": true
      },
      {
        "path": "/",
        "name": "welcome",
        "icon": "smile",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
        "hideInMenu": true,
        "exact": true
      },
      {
        "path": "/quan-ly-van-bang",
        "name": "quan-ly-van-bang",
        "icon": "crown",
        "routes": [
          {
            "path": "/quan-ly-van-bang/danh-sach-tot-nghiep",
            "name": "danh-sach-tot-nghiep",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__quan-ly-van-bang__danh-sach-tot-nghiep' */'I:/Projects/qlvb/qlvb_frontend/src/pages/quan-ly-van-bang/danh-sach-tot-nghiep'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-van-bang/phoi-van-bang",
            "name": "phoi-van-bang",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-van-bang/so-goc",
            "name": "so-goc",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-van-bang/cap-phat-van-bang-goc",
            "name": "cap-phat-van-bang-goc",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-van-bang/cap-phat-ban-sao",
            "name": "phoi-van-bang",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/thong-bao",
        "name": "thong-bao",
        "icon": "crown",
        "routes": [
          {
            "path": "/thong-bao/danh-sach-thong-bao",
            "name": "danh-sach-thong-bao",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/thong-bao/gui-thong-bao",
            "name": "gui-thong-bao",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/quan-ly-danh-muc",
        "name": "quan-ly-danh-muc",
        "icon": "crown",
        "routes": [
          {
            "path": "/quan-ly-danh-muc/khoa-hoc",
            "name": "khoa-hoc",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-danh-muc/don-vi",
            "name": "don-vi",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-danh-muc/dan-toc",
            "name": "dan-toc",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-danh-muc/don-vi-hanh-chinh",
            "name": "don-vi-hanh-chinh",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-danh-muc/xep-loai-tot-nghiep",
            "name": "xep-loai-tot-nghiep",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-danh-muc/hinh-thuc-dao-tao",
            "name": "hinh-thuc-dao-tao",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-danh-muc/van-ban-mau",
            "name": "van-ban-mau",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-danh-muc/mau-phoi",
            "name": "mau-phoi",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/bao-cao-thong-ke",
        "name": "bao-cao-thong-ke",
        "icon": "crown",
        "routes": [
          {
            "path": "/bao-cao-thong-ke/bao-cao-hoc-sinh-tot-nghiep",
            "name": "bao-cao-hoc-sinh-tot-nghiep",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/bao-cao-thong-ke/bao-cao-tinh-trang-su-dung-phoi",
            "name": "bao-cao-tinh-trang-su-dung-phoi",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/bao-cao-thong-ke/bao-cao-cap-phat-van-bang-goc",
            "name": "bao-cao-cap-phat-van-bang-goc",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/bao-cao-thong-ke/lich-su-truy-cap",
            "name": "lich-su-truy-cap",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/bao-cao-thong-ke/lich-su-khai-thac",
            "name": "lich-su-khai-thac",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/bao-cao-thong-ke/thong-ke-tra-cuu",
            "name": "thong-ke-tra-cuu",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/quan-ly-nhom-va-tai-khoan",
        "name": "quan-ly-nhom-va-tai-khoan",
        "icon": "crown",
        "routes": [
          {
            "path": "/quan-ly-nhom-va-tai-khoan/nhom-nguoi-dung",
            "name": "nhom-nguoi-dung",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-nhom-va-tai-khoan/nguoi-dung",
            "name": "nguoi-dung",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__quan-ly-nhom-va-tai-khoan__nguoi-dung' */'I:/Projects/qlvb/qlvb_frontend/src/pages/quan-ly-nhom-va-tai-khoan/nguoi-dung'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-nhom-va-tai-khoan/quyen-thao-tac",
            "name": "quyen-thao-tac",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/quan-ly-he-thong",
        "name": "quan-ly-he-thong",
        "icon": "crown",
        "routes": [
          {
            "path": "/quan-ly-he-thong/cau-hinh-he-thong",
            "name": "cau-hinh-he-thong",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-he-thong/du-lieu-mac-dinh",
            "name": "du-lieu-mac-dinh",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-he-thong/sao-luu-du-lieu",
            "name": "sao-luu-du-lieu",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/quan-ly-he-thong/khoi-phuc-du-lieu",
            "name": "khoi-phuc-du-lieu",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'I:/Projects/qlvb/qlvb_frontend/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'I:/Projects/qlvb/qlvb_frontend/src/pages/404'), loading: LoadingComponent}),
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
