import _ from 'moment/locale/pt-br';
export default _;
export * from 'moment/locale/pt-br';
