import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/dumi-theme-default/es/builtins/Example.js';
export default _;
