package com.bgddt.qlvb.entities;

public class Role {
    private String id;
}
