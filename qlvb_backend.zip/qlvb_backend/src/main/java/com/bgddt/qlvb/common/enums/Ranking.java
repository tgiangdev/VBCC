package com.bgddt.qlvb.common.enums;

public enum Ranking {
    GOOD,
    MEDIUM
}
