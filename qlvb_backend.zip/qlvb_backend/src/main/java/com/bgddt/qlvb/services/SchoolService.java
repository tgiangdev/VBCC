package com.bgddt.qlvb.services;

public interface SchoolService<O, T> extends BaseService<O, T> {
}
