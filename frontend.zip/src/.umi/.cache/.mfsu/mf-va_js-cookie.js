import _ from 'js-cookie';
export default _;
