export * from 'I:/Projects/qlvb/qlvb_frontend/node_modules/@umijs/preset-dumi/lib/theme';
