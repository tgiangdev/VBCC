import _ from 'I:/Projects/qlvb/qlvb_frontend/node_modules/core-js';
export default _;
export * from 'I:/Projects/qlvb/qlvb_frontend/node_modules/core-js';
