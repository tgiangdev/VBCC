package com.bgddt.qlvb.services;

public interface SchoolYearService<O, T> extends BaseService<O, T> {
}
